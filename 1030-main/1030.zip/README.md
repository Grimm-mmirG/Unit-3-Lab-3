# Lab Exercise

## Step 1
- Fork this repo to your own github account
- Clone the repo from your github account to your local machine

## Step 2
- Copy 2.py to a new file named 3.py
- Modify 3.py to use functions
    - Create a add function
    - Create a subtract function
    - Create a multiple function
    - Create a divide function

## Step 3
- Create a 'calculator' module
- Replicate your math functions in the calculator module

## Step 4
- create a file named "main.py"
- within main.py:
    - import the calculator module 
    - prompt the user to enter in two numbers
    - prompt the user to enter in an operation
    - use the calculator module to get the result of the requested operation

# Step 5
- Sync your local changes back to your github account
- Submit to D2L Assessments -> Unit 3 - Lab 3:
    - GitHub Repo link in comments
    - Zipfile containing your solution