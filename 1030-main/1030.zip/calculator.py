# def function for division
def divide(first_num, second_num):
    return first_num / second_num

# def function for multiplication
def multi(first_num, second_num):
    return first_num * second_num

# def function for addition
def add(first_num, second_num):
    return first_num + second_num

# def function for subtraction
def sub(first_num, second_num):
    return first_num - second_num
